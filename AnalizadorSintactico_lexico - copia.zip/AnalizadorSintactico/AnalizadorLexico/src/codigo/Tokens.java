/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigo;

/**
 *
 * @author Charly Ponce
 */
public enum Tokens {
    Linea,
    InicioPrograma,
    FinPrograma,
    TipoEntero,
    TipoDecimal,
    TipoCadena,
    TipoBooleano,
    SignoIgual,
    Suma,
    Resta,
    Multiplicacion,
    Division,
    InicioIf,
    FinIf,
    Else,
    FinElse,
    Comentario,
    MayorQue,
    MenorQue,
    IgualQue,
    DiferenteQue,
    MayorIgualQue,
    MenorIgualQue,
    InicioWhile,
    FinWhile,
    InicioDoWhile,
    FinDoWhile,
    InicioFor,
    FinFor,
    PuntoComa,
    AbreParentesis,
    CierraParentesis,
    CadenaDeTexto,
    NoNumero,
    Numero,
    Identificador,
    ERROR,
    RTrue,
    RFalse,
    NUMDECIMAL
}
